import json
import random
import boto3

# Initialize AWS SDK Clients
dynamodb = boto3.resource('dynamodb')
bedrock = boto3.client('bedrock-runtime', region_name='us-east-1')

# Target DynamoDB Table
table = dynamodb.Table('CloudFacts')

def lambda_handler(event, context):
    try:
        # 1. Fetch a random fact item from DynamoDB
        random_id = str(random.randint(1, 3))
        db_response = table.get_item(Key={'FactID': random_id})
        raw_fact = db_response.get('Item', {}).get(
            'fact', 
            'AWS S3 was launched in 2006 as one of the first cloud services.'
        )

        # 2. Format prompt
        prompt = f"Make this cloud computing fact witty, short, and engaging for a developer: '{raw_fact}'"
        
        body = json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 250,
            "messages": [
                {
                    "role": "user",
                    "content": prompt
                }
            ]
        })

        # 3. Invoke Bedrock using active Sonnet 4 inference profile
        bedrock_response = bedrock.invoke_model(
            modelId="us.anthropic.claude-sonnet-4-20250514-v1:0",
            contentType="application/json",
            accept="application/json",
            body=body
        )
        
        response_body = json.loads(bedrock_response['body'].read())
        witty_fact = response_body['content'][0]['text']

        # 4. Return API Gateway response with CORS
        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Methods": "OPTIONS,GET"
            },
            "body": json.dumps({"fact": witty_fact})
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "headers": {
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps({"error": str(e)})
        }